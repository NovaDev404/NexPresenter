using System;
using System.Collections.ObjectModel;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using NexPresenter.Models;
using NexPresenter.Services;

namespace NexPresenter.ViewModels;

public partial class SlideEditorViewModel : ViewModelBase
{
    private readonly DataStorageService _storageService;
    private readonly Presentation _presentation;

    [ObservableProperty]
    private ObservableCollection<Section> _sections = new();

    public SlideEditorViewModel(Presentation presentation)
    {
        _storageService = new DataStorageService();
        _presentation = presentation;
        
        // Load sections from presentation
        foreach (var section in presentation.Sections)
        {
            Sections.Add(section);
        }
    }

    [RelayCommand]
    private void AddSection(SectionType type)
    {
        var section = new Section
        {
            Id = Guid.NewGuid(),
            Name = type == SectionType.Song ? "New Song" : "New Section",
            Type = type
        };
        Sections.Add(section);
        _presentation.Sections.Add(section);
        _storageService.UpdatePresentation(_presentation);
    }

    [RelayCommand]
    private void AddSlide(Section section)
    {
        var slide = new Slide
        {
            Id = Guid.NewGuid(),
            Content = ""
        };
        section.Slides.Add(slide);
        _storageService.UpdatePresentation(_presentation);
    }

    [RelayCommand]
    private void DeleteSection(Section section)
    {
        Sections.Remove(section);
        _presentation.Sections.Remove(section);
        _storageService.UpdatePresentation(_presentation);
    }

    [RelayCommand]
    private void DeleteSlide(Section section, Slide slide)
    {
        section.Slides.Remove(slide);
        _storageService.UpdatePresentation(_presentation);
    }
}
