using Avalonia.Controls;

namespace NexPresenter.Views;

public partial class SlideEditorView : UserControl
{
    public SlideEditorView()
    {
        InitializeComponent();
    }
}
